## usage : x = codWithInterpolate(s, steererValues)
##
## calculate COD with given current of steerers (steerersValues [A])  
## and return the COD at specified position (s [m]) with linear interpolation.
##
## parameters:
## steererValue : matrix of current of steerers [A]
## s : matrix of position at which wanted COD
##
## global parametes :
## allElements,
## brho
## tune
## steererName : cell array of names of steerers which corresponding to steerersValues
## horv : horizontal or varticla. "h" is horizonntal. "v" is vertical.
## 
## result:
## COD[mm] at position s

function x = codWithInterpolate(s, steererValues)
  #printf("start codWithInterpolate\n")
  global _allElements;
  global _steererNames;
  global _brho;
  global _tune;
  global _horv;
  
#   steererValues
#   _steererNames
#   _allElements
#   _brho
#   _tune
#   _horv

  codList = calcCODWithPerror(_steererNames, steererValues, 0, _allElements, _brho,_tune,_horv);
  #codList = calcCOD(_steererNames,_steererValues,_allElements,_brho,_tune,_horv);
  x =  interp1(codList(:,1),codList(:,2),s,"linear");
endfunction
